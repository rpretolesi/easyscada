# KnxTemperatureSensor
Knx Temperature sensor (relies on KnxDevice library)

Visit http://liwan.fr/KnxWithArduino/ (post on KNX Temperature sensor) to get all the infos! 
